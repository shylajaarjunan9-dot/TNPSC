// Portfolio Data

const studentData = {

  name: "Alex Johnson",

  role: "Computer Science Student",

  about: "I am a passionate student focused on web development, data science, and building digital tools that solve real-world problems.",

  email: "alex.johnson@example.com",

  skills: ["HTML", "CSS", "JavaScript", "React", "Node.js"],

  projects: [

    {

      title: "Personal Blog",

      description: "A responsive blog website using HTML, CSS, and JavaScript.",

      link: "https://github.com/alexjohnson/personal-blog"

    },

    {

      title: "Weather App",

      description: "A web app that displays weather using OpenWeather API.",

      link: "https://github.com/alexjohnson/weather-app"

    }

  ]

};

// Populate HTML with data

document.getElementById("student-name").textContent = studentData.name;

document.getElementById("student-role").textContent = studentData.role;

document.getElementById("about-text").textContent = studentData.about;

document.getElementById("email").textContent = studentData.email;

// Skills

const skillsList = document.getElementById("skills-list");

studentData.skills.forEach(skill => {

  const li = document.createElement("li");

  li.textContent = skill;

  skillsList.appendChild(li);

});

// Projects

const projectList = document.getElementById("project-list");

studentData.projects.forEach(project => {

  const div = document.createElement("div");

  div.classList